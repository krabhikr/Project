package com.cg.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="distance_calculator")
public class DistanceCalculator {
	@Id
	@GeneratedValue
	@Column(name="distance_id")
	int id;
	String source;
	String destination;
	@Column(name="distance_in_km")
	double distanceInKm;
	@Column(name="distance_in_metres")
	int distanceInMetres;
	
	public DistanceCalculator(int id, String source, String destination, double distanceInKm, int distanceInMetres) {
		super();
		this.id = id;
		this.source = source;
		this.destination = destination;
		this.distanceInKm = distanceInKm;
		this.distanceInMetres = distanceInMetres;
	}
	public DistanceCalculator(String source, String destination, double distanceInKm, int distanceInMetres) {
		super();
		this.source = source;
		this.destination = destination;
		this.distanceInKm = distanceInKm;
		this.distanceInMetres = distanceInMetres;
	}
	public DistanceCalculator() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public double getDistanceInKm() {
		return distanceInKm;
	}
	public void setDistanceInKm(double distanceInKm) {
		this.distanceInKm = distanceInKm;
	}
	public int getDistanceInMetres() {
		return distanceInMetres;
	}
	public void setDistanceInMetres(int distanceInMetres) {
		this.distanceInMetres = distanceInMetres;
	}
	@Override
	public String toString() {
		return "DistanceCalculator [id=" + id + ", source=" + source + ", destination=" + destination
				+ ", distanceInKm=" + distanceInKm + ", distanceInMetres=" + distanceInMetres + "]";
	}
	
	
	
}
