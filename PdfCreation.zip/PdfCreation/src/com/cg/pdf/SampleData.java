package com.cg.pdf;

import java.io.FileOutputStream;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

public class SampleData {
	public void creation() {
		Document document = new Document();
		try {
			PdfWriter writer =PdfWriter.getInstance(document,new FileOutputStream("D:\\helloworld2.pdf"));
			document.open();
			document.add(new Paragraph("afdskajsdfak"));
			document.close();
			System.out.println("ahsdflkajdsflkjsadlkjsakfd");
			
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error Found");
		}
	}
}
