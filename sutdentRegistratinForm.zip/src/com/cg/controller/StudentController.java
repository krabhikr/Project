package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/StudentController")
public class StudentController extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		String name  = request.getParameter("name");
		String department  = request.getParameter("department");
		Double marks  = Double.parseDouble(request.getParameter("marks"));
		String mobilNumber  = request.getParameter("mobilNumber");
		Double percentage  = Double.parseDouble(request.getParameter("percentage"));
		
		
		request.setAttribute("name", name);
		request.setAttribute("department", department);
		request.setAttribute("marks", marks);
		request.setAttribute("mobilNumber", mobilNumber);
		request.setAttribute("percentage", percentage);
		
		
		request.getRequestDispatcher("success.jsp").forward(request, response);
		
		
	}
}
