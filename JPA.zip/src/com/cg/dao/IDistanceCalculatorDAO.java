package com.cg.dao;

import com.cg.model.DistanceCalculator;

public interface IDistanceCalculatorDAO {
	public boolean addCalculatedData(DistanceCalculator d);
}
