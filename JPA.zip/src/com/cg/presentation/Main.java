package com.cg.presentation;

import java.util.Scanner;

import com.cg.dao.DistanceCalculatorDAO;
import com.cg.model.DistanceCalculator;

public class Main {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter Source");
		String source = input.next();
		System.out.println("Enter Destination");
		String destination = input.next();
		System.out.println("Enter Distance in Kilo Metre");
		double distanceInKm = input.nextDouble();
		System.out.println("Enter Distance in Metre");
		int distanceInMetre = input.nextInt();
		
		
		
		
		//converting distance in km to distance in meter
		//int updateddistanceInMetre = distanceInKm
		
		
		//creating the object of DistanceCalculator
		DistanceCalculator distanceCalculator = new DistanceCalculator();
		
		//setting the value to object of DistanceCalculator
		distanceCalculator.setSource(source);
		distanceCalculator.setDestination(destination);
		distanceCalculator.setDistanceInKm(distanceInKm);
		distanceCalculator.setDistanceInMetres(distanceInMetre);
		
		//creating the object of DistanceCalculatorDAO
		
		DistanceCalculatorDAO distanceCalculatorDao = new DistanceCalculatorDAO();
		
		//pass the distanceCalculator object to addCalculatedData method
		boolean status = distanceCalculatorDao.addCalculatedData(distanceCalculator);
		
		if(status)System.out.println("Calculated Data inserted successfully");
		else System.out.println("Calculated Data not inserted successfully");

	}
}
