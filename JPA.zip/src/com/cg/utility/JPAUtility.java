package com.cg.utility;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

public class JPAUtility {
	static EntityManagerFactory factory= null;
	static {
		factory = Persistence.createEntityManagerFactory("distance_bu");
		
	}
	
	public static EntityManagerFactory getFactory() {
		return factory;
	}
}
