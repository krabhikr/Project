package cm.cg.eis.srvice;

import com.cg.eis.bean.Employee;

public interface EmployeeService {
	
	public Employee findInsurance(Employee e);
}
