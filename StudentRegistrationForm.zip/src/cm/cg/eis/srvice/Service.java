package cm.cg.eis.srvice;

import com.cg.eis.bean.Employee;

public class Service implements EmployeeService{

	@Override
	public Employee findInsurance(Employee e) {
		// TODO Auto-generated method stub
		double sal=e.getSal();
		if(e.getDesignation().equals("System Associate") && sal>5000 && sal<20000)
			e.setInsuranceSchm("Scheme C");
		else if(e.getDesignation().equals("Programmer") && sal>=20000 && sal<40000)
			e.setInsuranceSchm("Scheme B");
		else if(e.getDesignation().equals("Manager") && sal>40000)
			e.setInsuranceSchm("Scheme C");	
		else e.setInsuranceSchm("No Scheme");
		
		return e;
	}
	
}
