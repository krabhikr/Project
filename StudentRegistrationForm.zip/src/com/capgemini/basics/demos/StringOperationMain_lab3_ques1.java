package com.capgemini.basics.demos;

import java.util.Scanner;

public class StringOperationMain_lab3_ques1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Enter String ");
		String str= input.next(); 
		System.out.println("Enter 1 for Addition,Enter 2 for Replace,Enter 3 for Remove Duplicate,Enter 4 for converto upper case");
		int option = input.nextInt();
		StringOperation_lab3_ques_1 m= new StringOperation_lab3_ques_1();
		switch(option) {
		case 1:System.out.println("Output :"+m.AddString(str));
		break;
		case 2:System.out.println("Output :"+m.ReplaceChar(str));
		break;
		case 3:System.out.println("Output :"+m.RemoveChar(str));
		break;
		case 4:System.out.println("Output :"+m.toUpperCas(str));
		}

	}

}
