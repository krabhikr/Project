package com.capgemini.basics.demos;

public class CommandLine {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if(args.length==0) {
			System.out.println("Enter the numebrs from command line");
			
		}
		else {
			if(Integer.parseInt(args[0])>0) {
				System.out.println("Entered Number is a positive number");
			}
			else {
				System.out.println("Entered Number is a negative number");
			}
			
		}
	}

}
