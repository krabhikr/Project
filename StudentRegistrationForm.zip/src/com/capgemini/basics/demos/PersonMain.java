package com.capgemini.basics.demos;

import java.util.Scanner;

public class PersonMain {
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person m = new Person();
		Scanner input = new Scanner(System.in);
		String first_name=input.next();
		String last_name= input.next();
		Character gender=input.next().charAt(0);
		String phoneNumber = input.next();
		
		m.setFirst_name(first_name);
		m.setLast_name(last_name);
		m.setgender(gender);
		m.setPhoneNumber(phoneNumber);
		System.out.println("Person Details");
		System.out.println("________________");
		System.out.println("First Name: "+m.getFirst_name());
		System.out.println("Last Name: "+m.getLast_name());
		System.out.println("Gender "+m.getGender());
		System.out.println("Phone Number "+phoneNumber);
		
		

	}

}
