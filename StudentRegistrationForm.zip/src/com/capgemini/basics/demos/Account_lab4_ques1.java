package com.capgemini.basics.demos;

import java.util.Random;

public class Account_lab4_ques1 {
	long accNum;
	double balance;
	Person_lab4_ques1 accHolder;
	
	static  int acc=0;
	
	public Account_lab4_ques1() {
		super();
		this.accNum=(++acc);
	}

	public Account_lab4_ques1(double balance, Person_lab4_ques1 accHolder) {
		super();
		this.accNum =(++acc);;
		this.balance = balance;
		this.accHolder = accHolder;
	}
	
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person_lab4_ques1 getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person_lab4_ques1 accHolder) {
		this.accHolder = accHolder;
	}

	@Override
	public String toString() {
		return "Account_lab4_ques1 [accNum=" + accNum + ", balance=" + balance + ", accHolder=" + accHolder + "]";
	}
	
	public void deposite(double deposit) {
		this.balance+=deposit;
	}
	public void withdraw(double withdraw) {
		this.balance-=withdraw;
	}
	
	
	
}
