package com.capgemini.basics.demos;

import java.time.LocalDate;
import java.util.Scanner;

public class Product_purchaseMain_lab3_ques5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product_purchase_lab3_ques5 p = new Product_purchase_lab3_ques5();
		Scanner input = new Scanner(System.in);
		System.out.println("Enter Purchase date in format DD-MM-YYYY");
		String ans[] = input.nextLine().split("-");
		LocalDate date = LocalDate.of(Integer.parseInt(ans[2]), Integer.parseInt(ans[1]), Integer.parseInt(ans[0]));
		
		System.out.println("Enter Period of warranty year and month");
		int year = input.nextInt();
		int month = input.nextInt();
		p.setWarrantyMonth(month);
		p.setWarrantyYear(year);
		p.setD(date);
		
		date = p.Validty();
		System.out.println("Product will expire on "+date.getDayOfMonth()+"/"+date.getMonthValue()+"/"+date.getYear());


	}

}
