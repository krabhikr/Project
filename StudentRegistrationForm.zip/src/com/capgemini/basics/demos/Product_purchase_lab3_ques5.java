package com.capgemini.basics.demos;

import java.time.LocalDate;
import java.time.Period;

public class Product_purchase_lab3_ques5 {
	LocalDate D;
	int WarrantyMonth;
	int WarrantyYear;
	
	
	
	public Product_purchase_lab3_ques5() {
		super();
	}
	
	
	public Product_purchase_lab3_ques5(LocalDate d, int warrantyMonth, int warrantyYear) {
		super();
		D = d;
		WarrantyMonth = warrantyMonth;
		WarrantyYear = warrantyYear;
	}


	public int getWarrantyMonth() {
		return WarrantyMonth;
	}

	public void setWarrantyMonth(int warrantyMonth) {
		WarrantyMonth = warrantyMonth;
	}

	public int getWarrantyYear() {
		return WarrantyYear;
	}

	public void setWarrantyYear(int warrantyYear) {
		WarrantyYear = warrantyYear;
	}

	public LocalDate getD() {
		return D;
	}
	public void setD(LocalDate d) {
		D = d;
	}
	@Override
	public String toString() {
		return "Product_purchase_lab3_ques5 [D=" + D + "]";
	}
	
	public LocalDate Validty() {
		int month =D.getMonthValue()+WarrantyMonth;
		return LocalDate.of(D.getYear()+WarrantyYear+(month/12),month%12,D.getDayOfMonth());
	}
	
	
}
