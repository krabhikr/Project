package com.capgemini.basics.demos;

public class Main_lab4_ques1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account_lab4_ques1 a = new Account_lab4_ques1();
	    Person_lab4_ques1 p = new Person_lab4_ques1();
	    p.setName("Smith");
	    p.setAge(25);
		a.setBalance(2000);
		a.setAccHolder(p);
		Account_lab4_ques1 a1 = new Account_lab4_ques1();
		p.setName("Kathy");
		p.setAge(30);
		a1.setAccHolder(p);
		a1.setBalance(3000);
		
		//b
		a.deposite(2000);
		a1.withdraw(2000);
		
		System.out.println("Account Number "+a.getAccNum()+"\nName "+a.accHolder.name+"\nAvailable Balance "+a.getBalance());
		System.out.println("Account Number "+a1.getAccNum()+"\nName "+a1.accHolder.name+"\nAvailable Balance "+a1.getBalance());
		
		System.out.println(a);
		System.out.println(a1);
	}

}
