package com.capgemini.basics.demos;

public class Person_lab4_ques1 {
	String name;
	float age;
	
	
	
	public Person_lab4_ques1() {
		super();
	}
	
	public Person_lab4_ques1(String name, float age) {
		super();
		this.name = name;
		this.age = age;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Person_lab4_ques1 [name=" + name + ", age=" + age + "]";
	}
	
	
}
