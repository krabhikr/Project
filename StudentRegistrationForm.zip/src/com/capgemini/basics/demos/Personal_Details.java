package com.capgemini.basics.demos;

public class Personal_Details {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			System.out.println("Personal Details");
			System.out.println("______________");
			System.out.println("First Name: Abhishek");
			System.out.println("Last Name: Kumar");
			System.out.println("Gender: M");
			System.out.println("Age: 21");
	}

}
