package com.capgemini.basics.demos;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class Date_lab3_ques4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Enter Year");
		int year = input.nextInt();
		System.out.println("Enter Month");
		int month = input.nextInt();
		System.out.println("Enter Day");
		int day =input.nextInt();

		System.out.println("Enter Year");
		int year1 = input.nextInt();
		System.out.println("Enter Month");
		int month1 = input.nextInt();
		System.out.println("Enter Day");
		int day1 =input.nextInt();
		LocalDate start = LocalDate.of( year ,month , day ) ;
		LocalDate stop = LocalDate.of( year1 ,month1 , day1 );
		
		Period p = Period.between(start, stop);
		System.out.println("Years "+Math.abs(p.getYears()));
		System.out.println("Months "+Math.abs(p.getMonths()));
		System.out.println("Days "+Math.abs(p.getDays()));


	}

}
