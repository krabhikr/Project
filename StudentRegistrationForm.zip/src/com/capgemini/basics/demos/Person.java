package com.capgemini.basics.demos;

public class Person {
	String First_name;
	String Last_name;
	Character gender;
	
	String phoneNumber;//for assignment 2.4
	
	public Person() {
		super();
	}

	public Person(String first_name, String last_name, Character gender) {
		super();
		First_name = first_name;
		Last_name = last_name;
		this.gender = gender;
	}

	void setFirst_name(String first_name) {
		this.First_name=first_name;
	}
	
	String getFirst_name() {
		return this.First_name;
	}
	void setLast_name(String last_name) {
		this.Last_name=last_name;
	}
	String getLast_name() {
		return this.Last_name;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	void setgender(Character gender) {
		this.gender=gender;
	}
	Character getGender() {
		return this.gender;
	}
}
