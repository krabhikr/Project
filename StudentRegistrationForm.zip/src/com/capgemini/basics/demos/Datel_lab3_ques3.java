package com.capgemini.basics.demos;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class Datel_lab3_ques3 {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);
		System.out.println("Enter Year");
		int year = input.nextInt();
		System.out.println("Enter Month");
		int month = input.nextInt();
		System.out.println("Enter Day");
		int day =input.nextInt();
		
		
		//System.out.println(d1);
		LocalDate start = LocalDate.of( year ,month , day ) ;
		LocalDate stop = LocalDate.now();
		//long days = java.time.temporal.ChronoUnit.DAYS.between( start , stop );
		//System.out.println(days);
		//System.out.println("No of years : "+days/365.25+"\n"+"No of Month : "+(days%(365))/30+"\n"+"No of days : "+(days%365)%30);
		Period p = Period.between(start, stop);
		System.out.println("Years "+p.getYears());
		System.out.println("Months "+p.getMonths());
		System.out.println("Days "+p.getDays());

	}

}
