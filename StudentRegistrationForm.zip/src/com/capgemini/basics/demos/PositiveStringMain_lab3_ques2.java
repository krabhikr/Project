package com.capgemini.basics.demos;

import java.util.Scanner;

 class PositiveString{
	boolean checkPoitive(String str) {
		for(int i=1;i<str.length();i++) {
			if(str.charAt(i)<str.charAt(i-1))return false;
		}
		return true;
	}
}

public class PositiveStringMain_lab3_ques2 {
	
	
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter String");
		String str = input.next();
		PositiveString p= new PositiveString();
		
		if(p.checkPoitive(str))System.out.println("Positive String");
		else System.out.println("Negative String");
	}
}
