package com.capgemini.basics.demos;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;




public class Zone_lab3_ques6 {

	 public static void zoneNameAccepter() {
		 	Scanner input = new  Scanner(System.in);
			System.out.println("Enter the Zone Id");
			String ZoneName= input.next();
			ZonedDateTime zonTime = ZonedDateTime.now(ZoneId.of(ZoneName));
			System.out.println(zonTime);
	 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			zoneNameAccepter();
		

	}

}
