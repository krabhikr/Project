package com.capgemini.basics.demos;

public class StringOperation_lab3_ques_1 {
	
     public String AddString(String str) {
  
    	 return str+str;
     }
     
     public String ReplaceChar(String str) {
    	 String s="";
    	 for(int i=0;i<str.length();i++) {
    		 if(i%2==0)s+=str.charAt(i);
    		 else s+='#';
    	 }
    	 return s.toString();
     }
     
     public String RemoveChar(String str) {
    	 String s="";
    	 for(int i=0;i<str.length();i++) {
    		 if(!s.contains(str.charAt(i)+"")) {
    			 s+=(str.charAt(i)+"");
    		 }
    		
    	 }
    	 return s;
     }
     
     public String toUpperCas(String str) {
    	 String s="";
    	 for(int i=0;i<str.length();i++) {
    		 if(i%2==0)s+=str.charAt(i);
    		 else
    		 	s+=(str.charAt(i)+"").toUpperCase();
    	 }
    	 return s;
     }
     
}
