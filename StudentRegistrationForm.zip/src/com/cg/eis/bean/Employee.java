package com.cg.eis.bean;

public class Employee {
	int EmployeeId;
	String EmployeeName;
	int sal;
	String designation;
	String insuranceSchm;
	
	
	
	public Employee() {
		super();
	}



	public Employee(int employeeId, String employeeName, int sal, String designation, String insuranceSchm) {
		super();
		EmployeeId = employeeId;
		EmployeeName = employeeName;
		this.sal = sal;
		this.designation = designation;
		this.insuranceSchm = insuranceSchm;
	}



	public int getEmployeeId() {
		return EmployeeId;
	}



	public void setEmployeeId(int employeeId) {
		EmployeeId = employeeId;
	}



	public String getEmployeeName() {
		return EmployeeName;
	}



	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}



	public int getSal() {
		return sal;
	}



	public void setSal(int sal) {
		this.sal = sal;
	}



	public String getDesignation() {
		return designation;
	}



	public void setDesignation(String designation) {
		this.designation = designation;
	}



	public String getInsuranceSchm() {
		return insuranceSchm;
	}



	public void setInsuranceSchm(String insuranceSchm) {
		this.insuranceSchm = insuranceSchm;
	}



	@Override
	public String toString() {
		return "Employee [EmployeeId=" + EmployeeId + ", EmployeeName=" + EmployeeName + ", sal=" + sal
				+ ", designation=" + designation + ", insuranceSchm=" + insuranceSchm + "]";
	}
	
	
}
