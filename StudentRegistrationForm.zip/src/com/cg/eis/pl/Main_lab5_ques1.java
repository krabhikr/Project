package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;

import cm.cg.eis.srvice.Service;

public class Main_lab5_ques1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Enter Employee Id");
		int EmployeeId= input.nextInt();
		System.out.println("Enter Employee Name");
		String EmployeeName= input.next();
		System.out.println("Enter Employee salary");
		int EmployeeSalary = input.nextInt();
		System.out.println("Enter Designation");
		String EmployeeDsg= input.next();
		
		Employee e= new Employee();
	    e.setDesignation(EmployeeDsg);
	    e.setEmployeeId(EmployeeId);
	    e.setEmployeeName(EmployeeName);
	    e.setSal(EmployeeSalary);
	    
		
		Service s= new Service();
		e=s.findInsurance(e);
		System.out.println("Employee id "+e.getEmployeeId()+"\nEmployee Name "+e.getEmployeeName()+"\nEmployee Designation "+e.getDesignation()+"\nEmployee Salary "+e.getSal()+"\nInsurance System "+e.getInsuranceSchm());
		
	}

}
