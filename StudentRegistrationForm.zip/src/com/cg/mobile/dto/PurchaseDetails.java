package com.cg.mobile.dto;

import java.util.Date;

import com.cg.mobile.dao.PurchaseDAOImpl;

public class PurchaseDetails{
	private static Integer purchaseId = 0;
	private String cname;
	private String mailId;
	private String phoneNo;
	private Date purchaseDate;
	
	private String mobileName;
	private int mobileId;
	public PurchaseDetails(Integer purchaseId, String cname, String mailId, String phoneNo, Date purchaseDate,
			String mobileName) throws Exception {
		super();
		purchaseId = purchaseId + 1;
		this.cname = cname;
		this.mailId = mailId;
		this.phoneNo = phoneNo;
		this.purchaseDate = purchaseDate;
		this.mobileId = PurchaseDAOImpl.getMobileIdMethod(mobileName);
	}
	
	public int getMobileId() {
		return mobileId;
	}

	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}

	public int getMobileName() throws Exception {
		return PurchaseDAOImpl.getMobileIdMethod(mobileName);
	}
	
	
	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}

	public PurchaseDetails() {
		super();
		purchaseId = purchaseId + 1;
		
	}
	public Integer getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(Integer purchaseId) {
		this.purchaseId = purchaseId;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public Date getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	@Override
	public String toString() {
		return "PurchaseDetails [purchaseId=" + purchaseId + ", cname=" + cname + ", mailId=" + mailId + ", phoneNo="
				+ phoneNo + ", purchaseDate=" + purchaseDate + "]";
	}

}
