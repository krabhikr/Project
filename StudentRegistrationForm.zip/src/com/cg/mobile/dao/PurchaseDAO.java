package com.cg.mobile.dao;

import com.cg.mobile.dto.PurchaseDetails;

public interface PurchaseDAO {
	
	public void addCustomer(PurchaseDetails pd) throws Exception;
	
	public void viewMobileDetails() throws Exception;
	
	public void deleteMobile(int id) throws Exception;
	

}
