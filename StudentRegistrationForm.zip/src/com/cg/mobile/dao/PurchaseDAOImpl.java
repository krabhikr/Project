package com.cg.mobile.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.mobile.dto.PurchaseDetails;

public class PurchaseDAOImpl implements PurchaseDAO{

	@Override
	public void addCustomer(PurchaseDetails pd) throws Exception {
		// TODO Auto-generated method stub
		
		Connection conn = null;
		try {
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "system";
		String password = "Capgemini123";
	    conn = DriverManager.getConnection(url, user, password);
		PreparedStatement ps = conn.prepareStatement("insert into purchasedetails values(?,?,?,?,?,?)");
		ps.setInt(1,pd.getPurchaseId());
		ps.setString(2,pd.getCname());
		ps.setString(3,pd.getMailId());
		ps.setString(4,pd.getPhoneNo());
		Date d = new Date(pd.getPurchaseDate().getYear(), pd.getPurchaseDate().getMonth(), pd.getPurchaseDate().getDay());
		ps.setDate(5,d);
		ps.setInt(6,pd.getMobileName());       //id
		PreparedStatement ps2 = conn.prepareStatement("update mobiles set quantity=quantity-1 where mobileid = ?");
		ps2.setInt(1,pd.getMobileName());
		ps2.executeUpdate();
		int rows = ps.executeUpdate();
		System.out.println("from addCustomer " + rows);
		} catch(Exception e1) {
	       throw e1;
		}
		finally {
			if(conn != null)
		         conn.close();
		}	
		
	}

	public static int getMobileIdMethod(String mobileName) throws Exception {
		// TODO Auto-generated method stub
		int id = 0;
		Connection conn = null;
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "system";
		String password = "Capgemini123";
	    conn = DriverManager.getConnection(url, user, password);
	    System.out.println("from getMobileId name: "+mobileName);
		PreparedStatement ps = conn.prepareStatement("select mobileId from mobiles where name = ?");
		ps.setString(1, mobileName);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			id = rs.getInt("mobileId");
		}
		System.out.println("from purchaseDaoImpl:"+id);
		return id;
	}

	public void viewMobileDetails() throws Exception {
		// TODO Auto-generated method stub
		Connection conn = null;
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "system";
		String password = "Capgemini123";
	    conn = DriverManager.getConnection(url, user, password);
	    PreparedStatement ps = conn.prepareStatement("select * from mobiles");
	    ResultSet rs = ps.executeQuery();
	    while(rs.next()) {
	    	int id = rs.getInt("mobileId");
	    	String name = rs.getString("name");
	    	int price = rs.getInt("price");
	    	String quantity = rs.getString("quantity");
	    	System.out.println(" Id: "+id +" Name: "+name +" Price: "+ price +" Quantity: "+quantity);	    	
	    }
		conn.close();		
	}

	public void deleteMobile(int id) throws Exception {
		// TODO Auto-generated method stub
		Connection conn = null;
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "system";
		String password = "Capgemini123";
	    conn = DriverManager.getConnection(url, user, password);
	    PreparedStatement ps = conn.prepareStatement("delete from mobiles where mobileId = ?");
	    ps.setInt(1,id);
	    int res = ps.executeUpdate();
	    if(res > 0) {
	    	System.out.println("Deleted successfully");
	    } 
	}

	public void searchMobile(int price) throws Exception {
		// TODO Auto-generated method stub
		Connection conn = null;
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "system";
		String password = "Capgemini123";
	    conn = DriverManager.getConnection(url, user, password);
	    PreparedStatement ps = conn.prepareStatement("select * from mobiles where price = ?");
	    ps.setInt(1,price);
	    ResultSet rs = ps.executeQuery();
	    while(rs.next()) {
	    	int id = rs.getInt("mobileId");
	    	String name = rs.getString("name");
	    	int mobPrice = rs.getInt("price");
	    	String quantity = rs.getString("quantity");
	    	System.out.println(" Id: "+id +" Name: "+name +" Price: "+ mobPrice +" Quantity: "+quantity);	    	
	    }
		
		
	}

}
