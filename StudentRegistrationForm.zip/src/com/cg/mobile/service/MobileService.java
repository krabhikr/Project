package com.cg.mobile.service;

import com.cg.mobile.dto.PurchaseDetails;

public interface MobileService {
	
	public String addCustomer(PurchaseDetails pd) throws Exception;
	
	public void viewMobileDetails() throws Exception;

	public void deleteMobile(int id) throws Exception;

	public void searchMobile(int price) throws Exception;

}
