package com.cg.lab13;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Locale;

public class Program2 implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		while(true) {
			LocalDateTime t = LocalDateTime.now();
			System.out.println(t);
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
