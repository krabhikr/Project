package com.cg.lab13;

public class Program2Test {
	public static void main(String[] args) {
		Program2 p = new Program2();
		Thread t = new Thread(p);
		t.start();
		
	}
}
