package com.cg.lab10;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class Program10_1b {
	public static void main(String[] args) throws Exception {
		Properties p = new Properties();
		FileInputStream in = new FileInputStream("PersonProps.properties");
		p.load(in);
		System.out.println(p.getProperty("url"));
		System.out.println(p.getProperty("username"));
		System.out.println(p.getProperty("password"));
	}
}
