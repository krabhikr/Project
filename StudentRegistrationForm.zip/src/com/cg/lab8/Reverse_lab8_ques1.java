package com.cg.lab8;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;

public class Reverse_lab8_ques1 {
	public static void main(String[] args) throws Exception {

		StringBuilder s = new StringBuilder();
		FileReader fr = new FileReader("test.txt");
		int sr=fr.read();
		while(sr!=-1) {
			s.append(sr+" ");
			sr=fr.read();
		}
		s.reverse();
		System.out.println(s);
		fr.close();
		BufferedWriter bw = new BufferedWriter(new FileWriter("test.txt"));
		bw.write(s.toString());
		bw.close();
	    
		
		
	}
}
