package com.cg.lab8;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Program8_1 {
	public static void main(String[] args) throws Exception {
		
		
		
		FileReader fis = new FileReader("test.txt"); //true = append mode
		BufferedReader br = new BufferedReader(fis);
		//BufferedOutputStream bos = new BufferedOutputStream(fos);
		//DataOutputStream dos = new DataOutputStream(bos);//helps to write primitive data types
		
		String str,ans="";
		while((str = br.readLine()) != null) {
			 ans += str;
		}
		System.out.println(ans);
		
		FileWriter fos = new FileWriter("test1.txt"); //true = append mode
		//BufferedWriter bos = new BufferedWriter(fos);
		
		for(int i = ans.length()-1; i >= 0; i--)
			fos.write(ans.charAt(i));
		
	}
}
