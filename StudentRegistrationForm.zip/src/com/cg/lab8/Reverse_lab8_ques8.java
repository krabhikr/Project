package com.cg.lab8;

public class Reverse_lab8_ques8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
