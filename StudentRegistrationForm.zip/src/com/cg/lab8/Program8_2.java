package com.cg.lab8;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Program8_2 {
	public static void main(String[] args) throws FileNotFoundException {
		File f = new File("numbers.txt");
		Scanner sc = new Scanner(f);
		String str = "";
		while(sc.hasNext()) {
			str += sc.next();
		}
		String[] arr = str.split(",");
		for(int i = 0; i < arr.length; i++) 
			if((Integer.parseInt(arr[i]+"")%2 == 0))
				System.out.println(arr[i]);
	}
}
