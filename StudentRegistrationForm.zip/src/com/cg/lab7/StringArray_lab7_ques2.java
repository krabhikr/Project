package com.cg.lab7;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class StringArray_lab7_ques2 {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner( System.in);
		System.out.println("Enter the number of products you want to enter");
		int size = input.nextInt();
		System.out.println("Enter "+size+" Elements: ");
		ArrayList<String> product = new ArrayList<String>();
		for(int i=0;i<size;i++){
			
			product.add(input.next());
		}
		
		Collections.sort(product);
		
		System.out.println("Product in sorted order with respect to their names");
		for(String s: product) {
			System.out.println(s);
		}

	}

}
