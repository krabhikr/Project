package com.cg.lab7;

import java.util.Arrays;
import java.util.Scanner;

public class StringArray_lab7_ques1 {

	public static void main(String[] args) {
		
		
		
		Scanner input = new Scanner( System.in);
		System.out.println("Enter the number of products you want to enter");
		int size = input.nextInt();
		System.out.println("Enter "+size+" Elements: ");
		String[] product = new String[size];
		for(int i=0;i<size;i++){
			
			product[i]=input.next();
		}
		
		Arrays.sort(product);
		
		System.out.println("Product in sorted order with respect to their names");
		for(int i=0;i<size;i++) {
			System.out.println(product[i]);
		}

		
	}
}
