package com.cg.lab7;

import java.util.Scanner;

import com.cg.eis.bean.Employee;

public class Lab7_ques3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		Employee  e = new Employee();
		System.out.println("Enter Employee Id");
		e.setEmployeeId(input.nextInt());
		System.out.println("Enter Employee Name");
		e.setEmployeeName(input.next());
		System.out.println("Enter Employee Sal");
		e.setSal(input.nextInt());
		System.out.println("Enter Employee Designation");
		e.setInsuranceSchm(input.next());
		
	}

}
