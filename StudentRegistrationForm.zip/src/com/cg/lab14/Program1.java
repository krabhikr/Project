package com.cg.lab14;

public class Program1 {
	public static void main(String[] args) {

		LambdaExp mi1 = (x, y) -> Math.pow(x, y);
		System.out.println(mi1.power(5.0, 2.0));
	}
}
interface LambdaExp{
	public abstract double power(double x, double y);
}