package com.cg.lab14;

public class Program5Help {
	public static int fact(int num) {
		int res = 1;
		while(num != 0) {
			res *= num;
			num--;
		}
		return res;
	}
}
