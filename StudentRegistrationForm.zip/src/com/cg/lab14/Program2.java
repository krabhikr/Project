package com.cg.lab14;

import java.util.function.Function;

public class Program2 {
	public static void main(String[] args) {
		Function<String,String> s = (str) -> {
			String ans = "";
			for(int i = 0; i < str.length(); i++) {
				ans += str.charAt(i)+" ";
			}
			return ans;
		};
		System.out.println(s.apply("string"));
	}
}