package com.cg.lab14;

import java.util.function.Function;

public class Program4 {
	public static void main(String[] args) {
		Employee e = new Employee();
		e.setEmpNo(1);
		Function<Employee, Integer> emp = Employee :: getEmpNo;
		System.out.println("EmpId : "+emp.apply(e));
	}
}
